
class PolyTreeNode
    attr_reader :value, :parent, :children

    def initialize(value, parent = nil)
        @value = value
        @parent = parent
        @children = []
    end

    def parent=(parent)
        return  if self.parent == parent                     
        if self.parent
            self.parent.children.delete(self) 
        end
        @parent = parent
        parent.children << self unless parent.nil?
        self
    end

    def add_child(child)
        child.parent = self
    end

    def remove_child(child)
        if child && !self.children.include?(child)
            raise "error"
        end
        child.parent = nil
    end


    def dfs(target = nil, &prc)
        prc ||=  Proc.new {|node| node.value == target}

        return self if prc.call(self)

        self.children.each do |child|
            result = child.dfs(&prc)
            return result unless result.nil?
        end
    nil
    end

    def bfs(target = nil, &prc)
        prc ||=  Proc.new {|node| node.value == target}

        nodes = [self]
        until nodes.empty?
            node = nodes.shift

            return node if prc.call(node)
            nodes += node.children 
        end
        nil
    end

end
