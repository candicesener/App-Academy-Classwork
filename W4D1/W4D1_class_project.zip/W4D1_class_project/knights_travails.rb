require_relative "00_tree_node.rb"

class KnightPathFinder

    attr_reader :considered_positions

    MOVES = [[1, 2], [2, 1], [-1, 2], [-1, -2], [-2, 1], [-2, -1], [2, -1], [1, -2]]

    

    def self.valid_moves(position)
        result = []
        #(0,7) x,y + 1,2 --- x+1,y+2 --- 0,7(8x8)
        x, y = position
        MOVES.each do |(a,b)|
            new_pos = ([x+a, y+b])
            if (new_pos[0] >= 0 && new_pos[0] <= 7) && (new_pos[1] >= 0 && new_pos[1] <= 7)
                result << new_pos
            end
        end
        result
    end

    def initialize(start_position)
        @start_position = start_position
        @root_node = PolyTreeNode.new(start_position)
        @considered_positions = [start_position]
        build_move_tree
    end

    def new_move_positions(pos)
        selected = KnightPathFinder.valid_moves(pos).select {|candidate| !@considered_positions.include?(candidate)}
        selected.each {|new_pos| @considered_positions << new_pos}
    end

    def build_move_tree
        nodes = [@root_node] # ----- [1,2,3]

        until nodes.empty?
            current_node = nodes.shift
            new_move_positions(current_node.value).each do |pos|
                new_node = PolyTreeNode.new(pos)
                current_node.add_child(new_node)
                nodes << new_node
            end

        end
    end

    def find_path(last_node)
        result = []
        current_node = last_node

        until current_node.nil?
            result <<  current_node
            current_node = current_node.parent
        end
        result
    end
end

    # def bfs(target = nil, &prc)
    #     prc ||=  Proc.new {|node| node.value == target}

    #     nodes = [self]
    #     until nodes.empty?
    #         node = nodes.shift

    #         return node if prc.call(node)
    #         nodes += node.children 
    #     end
    #     nil
    # end